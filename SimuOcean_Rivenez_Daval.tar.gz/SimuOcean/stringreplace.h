#ifndef STRINGREPLACE_H
#define STRINGREPLACE_H

#ifdef __cplusplus
extern "C" {
#endif

	char *str_replace(const char *str, const char *old, const char *newStr);

#ifdef __cplusplus
}
#endif

#endif // STRINGREPLACE_H
