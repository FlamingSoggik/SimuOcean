#include "changermodeterminal.h"
#include <termios.h>
#include <unistd.h>

void mode_raw(int activer)
{
	static struct termios cooked;
	static int raw_actif = 0;

	if (raw_actif == activer)
		return;

	if (activer)
	{
		struct termios raw;

		tcgetattr(STDIN_FILENO, &cooked);

		raw = cooked;
		cfmakeraw(&raw);
		tcsetattr(STDIN_FILENO, TCSANOW, &raw);
	}
	else
		tcsetattr(STDIN_FILENO, TCSANOW, &cooked);

	raw_actif = activer;
}
