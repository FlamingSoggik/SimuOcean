#ifndef BOOL_H
#define BOOL_H

typedef enum Bool{
    False, True
}Bool;

#endif // BOOL_H
